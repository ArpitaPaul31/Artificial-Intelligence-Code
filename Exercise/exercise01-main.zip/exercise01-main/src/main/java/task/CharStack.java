package task;

public interface CharStack {
	void push(char c);
	char pop();
	int size();
}
