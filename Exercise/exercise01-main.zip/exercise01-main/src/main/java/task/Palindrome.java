package task;

public class Palindrome {
	public static boolean isPalindrome(String s) {

		// TODO: Use class CharStackImpl to test if string s is a palindrome

		return true;
	}
}
