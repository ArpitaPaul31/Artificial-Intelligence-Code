package task;


public class CharStackImpl implements CharStack {
	@Override
	public void push(char c) {
		// TODO: Implement interface method
	}

	@Override
	public char pop() {
		// TODO: Implement interface method
		return 0;
	}

	@Override
	public int size() {
		// TODO: Implement interface method
		return 0;
	}
}
