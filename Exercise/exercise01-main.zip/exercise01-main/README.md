# Quickstart

1. Open Intellij IDE
2. File -> New -> Project from Version Control...
    - Version Control: Git
    - URL: Link to git-repository
    - Directory: Choose any directory on your computer where the exercise folder should reside.
3. After having cloned the repository, you will find the .java sources in `src/main/java/` and the tests in `src/test/java/` 
